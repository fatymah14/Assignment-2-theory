package com.example.demo4;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class HelloApplication extends Application {

    private List<String> dataList = new ArrayList<>(); // To store submitted data

    @Override
    public void start(Stage stage) {
        // Create a BorderPane layout
        BorderPane rootPane = new BorderPane();

        // Banner Section
        HBox bannerBox = new HBox();
        bannerBox.setAlignment(Pos.CENTER);
        bannerBox.setPadding(new Insets(10));

        Label bannerLabel = new Label("DATA ENTRY FORM");
        bannerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        bannerLabel.setTextFill(Color.WHITE);
        bannerBox.setStyle("-fx-background-color: #4CAF50;");
        bannerBox.getChildren().add(bannerLabel);

        // Form Section (Center)
        GridPane formPane = new GridPane();
        formPane.setPadding(new Insets(20));
        formPane.setHgap(10);
        formPane.setVgap(15);
        formPane.setAlignment(Pos.TOP_CENTER);

        // Name Field
        Label nameLabel = new Label("Name:");
        nameLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        TextField nameField = new TextField();
        formPane.add(nameLabel, 0, 0);
        formPane.add(nameField, 1, 0);

        // Father's Name Field
        Label fatherNameLabel = new Label("Father Name:");
        fatherNameLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        TextField fatherNameField = new TextField();
        formPane.add(fatherNameLabel, 0, 1);
        formPane.add(fatherNameField, 1, 1);

        // City ComboBox
        Label cityLabel = new Label("City:");
        cityLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        ComboBox<String> cityComboBox = new ComboBox<>();
        cityComboBox.getItems().addAll("Lahore", "Karachi", "Islamabad", "Peshawar", "Quetta");
        cityComboBox.setPromptText("Select City");
        formPane.add(cityLabel, 0, 2);
        formPane.add(cityComboBox, 1, 2);

        // Address Field
        Label addressLabel = new Label("Address:");
        addressLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        TextField addressField = new TextField();
        formPane.add(addressLabel, 0, 3);
        formPane.add(addressField, 1, 3);

        // Email Field
        Label emailLabel = new Label("Email:");
        emailLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        TextField emailField = new TextField();
        formPane.add(emailLabel, 0, 4);
        formPane.add(emailField, 1, 4);

        // File Chooser for Image
        Label imageLabel = new Label("Image:");
        imageLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        Button imageButton = new Button("Choose File");
        Label selectedFileLabel = new Label("No file selected");
        imageButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Select Image");
            File file = fileChooser.showOpenDialog(stage);
            if (file != null) {
                selectedFileLabel.setText(file.getName());
            }
        });
        formPane.add(imageLabel, 0, 5);
        formPane.add(imageButton, 1, 5);
        formPane.add(selectedFileLabel, 1, 6);

        // Gender Radio Buttons
        Label genderLabel = new Label("Gender:");
        genderLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        ToggleGroup genderGroup = new ToggleGroup();
        RadioButton maleButton = new RadioButton("Male");
        RadioButton femaleButton = new RadioButton("Female");
        maleButton.setToggleGroup(genderGroup);
        femaleButton.setToggleGroup(genderGroup);
        HBox genderBox = new HBox(20, maleButton, femaleButton);
        formPane.add(genderLabel, 0, 7);
        formPane.add(genderBox, 1, 7);

        // Submit Button
        Button submitButton = new Button("Submit");
        submitButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        submitButton.setOnAction(e -> {
            // Gather and store data
            String name = nameField.getText();
            String fatherName = fatherNameField.getText();
            String city = cityComboBox.getValue();
            String address = addressField.getText();
            String email = emailField.getText();
            String gender = maleButton.isSelected() ? "Male" : femaleButton.isSelected() ? "Female" : "Not Selected";
            String image = selectedFileLabel.getText();

            // Store data in ArrayList
            dataList.add(String.format("Name: %s\nFather Name: %s\nCity: %s\nAddress: %s\nEmail: %s\nGender: %s\nImage: %s",
                    name, fatherName, city, address, email, gender, image));

            // Show next scene
            showNextScene(stage, name, fatherName, city, address, email, gender, image);
        });
        formPane.add(submitButton, 1, 8);

        // Add everything to the rootPane
        rootPane.setTop(bannerBox);
        rootPane.setCenter(formPane);

        // Set up the scene
        Scene scene = new Scene(rootPane, 700, 600);
        stage.setTitle("Data Entry Form");
        stage.setScene(scene);
        stage.show();
    }

    private void showNextScene(Stage stage, String name, String fatherName, String city, String address, String email, String gender, String image) {
        GridPane detailsPane = new GridPane();
        detailsPane.setPadding(new Insets(20));
        detailsPane.setHgap(10);
        detailsPane.setVgap(15);

        // Display submitted data
        detailsPane.add(new Label("Name:"), 0, 0);
        detailsPane.add(new Label(name), 1, 0);

        detailsPane.add(new Label("Father Name:"), 0, 1);
        detailsPane.add(new Label(fatherName), 1, 1);

        detailsPane.add(new Label("City:"), 0, 2);
        detailsPane.add(new Label(city), 1, 2);

        detailsPane.add(new Label("Address:"), 0, 3);
        detailsPane.add(new Label(address), 1, 3);

        detailsPane.add(new Label("Email:"), 0, 4);
        detailsPane.add(new Label(email), 1, 4);

        detailsPane.add(new Label("Gender:"), 0, 5);
        detailsPane.add(new Label(gender), 1, 5);

        detailsPane.add(new Label("Image:"), 0, 6);
        detailsPane.add(new Label(image), 1, 6);

        // Back Button
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> start(stage));
        detailsPane.add(backButton, 1, 7);

        // Set up the scene
        Scene detailsScene = new Scene(detailsPane, 700, 600);
        stage.setScene(detailsScene);
    }

    public static void main(String[] args) {
        launch();
    }
}
